def build_segformer(model_name="segformer_b0", num_classes=2):
    # TODO: plug an actual SegFormer implementation (e.g., from Hugging Face or mmseg)
    return None
