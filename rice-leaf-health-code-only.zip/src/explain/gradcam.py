def gradcam_heatmap(image, model):
    # TODO: implement Grad-CAM for classification models
    return None
