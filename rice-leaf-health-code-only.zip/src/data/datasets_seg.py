from torch.utils.data import Dataset
from PIL import Image
import os, numpy as np

class RiceSegDataset(Dataset):
    def __init__(self, img_root, mask_root, split_file, transform=None):
        self.img_root = img_root
        self.mask_root = mask_root
        self.transform = transform
        with open(split_file, "r") as f:
            self.items = [line.strip() for line in f if line.strip()]

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        rel = self.items[idx]
        img = Image.open(os.path.join(self.img_root, rel)).convert("RGB")
        mask_path = os.path.join(self.mask_root, rel).replace(".jpg", ".png")
        mask = Image.open(mask_path).convert("L")
        img_np = np.array(img); mask_np = np.array(mask)
        if self.transform:
            aug = self.transform(image=img_np, mask=mask_np)
            img_np, mask_np = aug["image"], aug["mask"]
        return img_np, mask_np
