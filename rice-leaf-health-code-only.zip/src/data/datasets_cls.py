# src/data/datasets_cls.py
from torch.utils.data import Dataset
from PIL import Image
import os

class RiceClsDataset(Dataset):
    """
    Split file format: 'relative_path,label'
    Ví dụ: public/rice_cls/blast/img001.jpg,0
    """
    def __init__(self, root, split_file, transform=None):
        self.root = root
        self.transform = transform
        with open(split_file, "r", encoding="utf-8") as f:
            self.items = [line.strip().split(",") for line in f if line.strip()]
        # ép nhãn sang int
        self.items = [(p, int(lbl)) for p, lbl in self.items]

    def __len__(self):
        return len(self.items)

    def __getitem__(self, idx):
        rel_path, label = self.items[idx]
        img_path = os.path.join(self.root, rel_path)
        img = Image.open(img_path).convert("RGB")   # dùng PIL
        if self.transform is not None:
            img = self.transform(img)               # torchvision: transform(PIL) -> Tensor
        return img, label
