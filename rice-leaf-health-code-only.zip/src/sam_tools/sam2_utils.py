def sam2_propose_mask(image):
    # TODO: integrate SAM2 to propose/refine lesion masks from prompts
    return None
