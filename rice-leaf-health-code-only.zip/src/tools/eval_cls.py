import argparse, json, os, torch, csv
from torchvision import transforms
from PIL import Image
import timm
import numpy as np
from sklearn.metrics import classification_report, confusion_matrix
from src.models.cnn_small import SmallCNN
def load_class_map(path):
    with open(path,"r",encoding="utf-8") as f:
        return [l.strip() for l in f if l.strip()]
def build_val_tf(sz):
    return transforms.Compose([
        transforms.Resize((sz,sz)),
        transforms.ToTensor(),
        transforms.Normalize((0.485,0.456,0.406),(0.229,0.224,0.225))
    ])
def load_model(ckpt, model_name, num_classes, device):
    if model_name=="cnn_small":
        model = SmallCNN(num_classes)
    else:
        model = timm.create_model(model_name, pretrained=False, num_classes=num_classes)
    sd = torch.load(ckpt, map_location=device)
    if isinstance(sd, dict) and "model" in sd:
        sd = sd["model"]
    model.load_state_dict(sd); model.to(device).eval()
    return model
def parse_split(fp):
    paths, labels = [], []
    with open(fp,"r",encoding="utf-8") as f:
        for line in f:
            line=line.strip()
            if not line: continue
            p, lab = line.rsplit(" ",1)
            paths.append(p); labels.append(int(lab))
    return paths, labels
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model_name", required=True)
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--split_file", required=True)
    ap.add_argument("--labels_file", required=True)
    ap.add_argument("--out_csv", default="eval_preds.csv")
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    class_names = load_class_map(args.labels_file); num_classes = len(class_names)
    tfm = build_val_tf(args.img_size)
    model = load_model(args.ckpt, args.model_name, num_classes, device)
    paths, y_true = parse_split(args.split_file)
    y_pred = []
    for p in paths:
        img = Image.open(p).convert("RGB")
        x = tfm(img).unsqueeze(0).to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(1).item()
        y_pred.append(pred)
    print(classification_report(y_true, y_pred, target_names=class_names, digits=4))
    cm = confusion_matrix(y_true, y_pred)
    print("Confusion matrix:\n", cm)
    with open(args.out_csv,"w",newline="",encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["path","true","pred"])
        for p,t,pr in zip(paths,y_true,y_pred):
            w.writerow([p,class_names[t],class_names[pr]])
    print("Saved:", args.out_csv)
if __name__ == "__main__":
    main()
