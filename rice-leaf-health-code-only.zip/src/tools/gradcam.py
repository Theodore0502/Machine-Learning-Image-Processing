import argparse, torch, cv2, numpy as np
from torchvision import transforms
from PIL import Image
import timm
from src.models.cnn_small import SmallCNN
def load_model(ckpt_path, model_name, num_classes, device):
    if model_name == "cnn_small":
        model = SmallCNN(num_classes=num_classes)
    else:
        model = timm.create_model(model_name, pretrained=False, num_classes=num_classes)
    sd = torch.load(ckpt_path, map_location=device)
    if isinstance(sd, dict) and "model" in sd:
        sd = sd["model"]
    model.load_state_dict(sd); model.to(device).eval()
    return model
class GradCAM:
    def __init__(self, model, target_layer):
        self.grad = None; self.act = None
        target_layer.register_forward_hook(self._fh)
        target_layer.register_full_backward_hook(self._bh)
    def _fh(self, m, i, o): self.act = o.detach()
    def _bh(self, m, gi, go): self.grad = go[0].detach()
    def __call__(self):
        w = self.grad.mean(dim=(2,3), keepdim=True)
        cam = (w * self.act).sum(dim=1, keepdim=True)
        cam = torch.relu(cam).squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() + 1e-8)
        return cam
def preprocess(p, sz):
    tfm = transforms.Compose([
        transforms.Resize((sz,sz)),
        transforms.ToTensor(),
        transforms.Normalize((0.485,0.456,0.406),(0.229,0.224,0.225))
    ])
    img = Image.open(p).convert("RGB")
    return tfm(img).unsqueeze(0), np.array(img)
def overlay(img_uint8, cam):
    h,w,_ = img_uint8.shape
    heat = cv2.applyColorMap((cam*255).astype(np.uint8), cv2.COLORMAP_JET)
    heat = cv2.cvtColor(heat, cv2.COLOR_BGR2RGB)
    heat = cv2.resize(heat, (w,h))
    return (0.4*heat + 0.6*img_uint8).astype(np.uint8)
def pick_layer(model, name):
    if name == "cnn_small": return model.features[-2]
    if hasattr(model, "layer4"): return model.layer4[-1]
    if hasattr(model, "blocks"):  return model.blocks[-1]
    raise RuntimeError("Chỉ định layer Grad-CAM chưa hỗ trợ.")
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model_name", required=True)
    ap.add_argument("--num_classes", type=int, default=4)
    ap.add_argument("--img", required=True)
    ap.add_argument("--img_size", type=int, default=224)
    ap.add_argument("--out", default="gradcam_vis.png")
    args = ap.parse_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = load_model(args.ckpt, args.model_name, args.num_classes, device)
    layer = pick_layer(model, args.model_name)
    cam = GradCAM(model, layer)
    x, raw = preprocess(args.img, args.img_size); x = x.to(device)
    x.requires_grad_(True)
    logits = model(x); pred = logits.argmax(1).item()
    loss = logits[0, pred]; model.zero_grad(set_to_none=True); loss.backward()
    vis = overlay(raw, cam())
    import os
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    cv2.imwrite(args.out, cv2.cvtColor(vis, cv2.COLOR_RGB2BGR))
    print(f"Saved {args.out}. Pred={pred}")
if __name__ == "__main__":
    main()
