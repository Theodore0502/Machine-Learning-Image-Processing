# tools/make_splits.py
import os, random, argparse, glob, pathlib, math

def main(root="data/public/rice_cls", out_dir="data/splits",
         train_ratio=0.7, val_ratio=0.15, seed=42):
    random.seed(seed)
    root = pathlib.Path(root)
    out = pathlib.Path(out_dir); out.mkdir(parents=True, exist_ok=True)

    classes = sorted([d.name for d in root.iterdir() if d.is_dir()])
    with open(out/"labels.txt", "w", encoding="utf-8") as f:
        for name in classes: f.write(name+"\n")

    items = []
    for ci, cname in enumerate(classes):
        for ext in ("*.jpg","*.jpeg","*.png","*.bmp"):
            for p in glob.glob(str(root / cname / ext)):
                rel = str(pathlib.Path("public") / "rice_cls" / cname / os.path.basename(p))
                items.append((rel, ci))

    by_class = {i:[] for i in range(len(classes))}
    for rel, ci in items: by_class[ci].append(rel)
    for ci in by_class: random.shuffle(by_class[ci])

    train, val, test = [], [], []
    for ci, rels in by_class.items():
        n = len(rels)
        n_tr = math.floor(n*train_ratio)
        n_va = math.floor(n*val_ratio)
        for i, rel in enumerate(rels):
            rec = f"{rel},{ci}"
            if i < n_tr: train.append(rec)
            elif i < n_tr + n_va: val.append(rec)
            else: test.append(rec)

    for name, lst in [("train_cls.txt", train), ("val_cls.txt", val), ("test_cls.txt", test)]:
        with open(out/name, "w", encoding="utf-8") as f:
            for rec in lst: f.write(rec+"\n")
    print("Done. Classes =", classes)
    print("Train/Val/Test =", len(train), len(val), len(test))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", type=str, default="data/public/rice_cls")
    ap.add_argument("--out_dir", type=str, default="data/splits")
    ap.add_argument("--train_ratio", type=float, default=0.7)
    ap.add_argument("--val_ratio", type=float, default=0.15)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()
    main(args.root, args.out_dir, args.train_ratio, args.val_ratio, args.seed)
